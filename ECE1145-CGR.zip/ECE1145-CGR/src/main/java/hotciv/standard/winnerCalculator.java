package hotciv.standard;

public interface winnerCalculator {
    int turncount = 0;
}
