package Strategies;

public interface Aging {
    public int calculateTime();
}
